import { timingSafeEqual } from 'node:crypto'
import { Request, Response } from 'express'
import { BamblooStatusCode } from '../../../../common/status'
import { user_manager } from '../../core/manager/user'
import { daily_session_manager } from '../../core/manager/daily-session'
import { response } from '../../util/secretary'
import { issue_session } from '../../util/session'
import { to_public_user } from '../../core/entity/user'

function same_hash(actual: string, expected: string) {
  const actualBuffer = Buffer.from(actual, 'hex')
  const expectedBuffer = Buffer.from(expected, 'hex')
  return (
    actualBuffer.length === expectedBuffer.length && timingSafeEqual(actualBuffer, expectedBuffer)
  )
}

export default function handler(params: { [key: string]: unknown }, req: Request, res: Response) {
  const account = typeof params.account === 'string' ? params.account.trim() : ''
  const passwordHash = typeof params.passwordHash === 'string' ? params.passwordHash : ''

  if (!account || !/^[a-f0-9]{64}$/i.test(passwordHash)) {
    return response(res, BamblooStatusCode.AuthenticationFail, '账号或密码错误')
  }

  return user_manager
    .instance()
    .then((manager) =>
      manager
        .get({ account })
        .catch(() => manager.get({ phone: account }))
        .catch(() => manager.get({ tag: account })),
    )
    .then((user) => {
      if (
        user.isActive === false ||
        typeof user.passwordHash !== 'string' ||
        !same_hash(passwordHash, user.passwordHash)
      ) {
        return response(res, BamblooStatusCode.AuthenticationFail, '账号或密码错误')
      }

      return daily_session_manager
        .recordLogin(user.tag)
        .then(() => daily_session_manager.getConsecutiveLoginDays(user.tag))
        .then((loginStreak) => {
          const token = issue_session(req, res, user)
          return response(res, BamblooStatusCode.Success, '登录成功', {
            ...to_public_user(user),
            loginStreak,
            token,
          })
        })
    })
    .catch(() => response(res, BamblooStatusCode.AuthenticationFail, '账号或密码错误'))
}
